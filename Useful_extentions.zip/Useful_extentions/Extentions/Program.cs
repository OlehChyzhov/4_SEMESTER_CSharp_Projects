﻿using System.Runtime.CompilerServices;

static class MyExtantions
{
    public static string Truncate(this string str, int max_length)
    {
        string new_line = "";
        if (str.Count() > max_length)
        {
            for (int i = 0; i < max_length; i++)
            {
                new_line += str[i];
            }
            new_line += "...";
        }
        else
        {
            new_line = str;
        }
        
        return new_line;
    }
    public static int WordCount(this string str)
    {
        string[] words = str.Split(" ");
        int counter = words.Length;
        return counter;
    }
    public static int GetQuater(this DateTime date_time)
    {
        int result = -1;
        switch (date_time.Month)
        {
            case 1:
            case 2:
            case 3:
                result = 1;
            break;
            case 4:
            case 5:
            case 6:
                result = 2;
                break;
            case 7:
            case 8:
            case 9:
                result = 3;
                break;
            case 10:
            case 11:
            case 12:
                result = 4;
                break;
            default:
                break;
        }
        return result;
    }
    public static IEnumerable<T> TakeUntill<T>(this IEnumerable<T> source, int end)
    {
        int current_index = 0;
        List<T> new_collection = new List<T>();
        foreach (var item in source)
        {
            if (current_index < end)
            {
                new_collection.Add(item);
                ++current_index;
            }
            else break;
        }
        return new_collection;
    }
    public static string ToString_MY<T>(this IEnumerable<T> source)
    {
        string line = "[";

        foreach (var item in source)
        {
            line += $"{item},";
        }
        line += "]";
        return line;
    }

    public static double MathExpectation(this Dictionary<double, double> source)
    {
        double expectation = 0;
        foreach (var item in source)
        {
            expectation += item.Key * item.Value;
        }
        return expectation;
    }
    public static double StandardDeviation(this Dictionary<double, double> source, int n, double x_middle)
    {
        double deviation = 0;
        foreach (var item in source)
        {
            deviation += Math.Pow(item.Key - x_middle, 2);
        }
        return deviation/n;
    }
}
class Program
{
    
    static void Main(string[] args)
    {
        string text = "Really long sentence";
        Console.WriteLine($"Sentence: {text}");
        Console.WriteLine($"Short sentence: {text.Truncate(5)}");
        Console.WriteLine($"Word count: {text.WordCount()}");

        DateTime date_time = new DateTime(2024, 12, 1);
        Console.WriteLine($"Quater: {date_time.GetQuater()}");

        List<int> my_list = new List<int>();
        my_list.Add(5);
        my_list.Add(4);
        my_list.Add(3);
        my_list.Add(2);
        my_list.Add(1);
        IEnumerable<int> new_list = (my_list).TakeUntill(3);
        foreach (var item in new_list)
        {
            Console.WriteLine($"{item} ");
        }
        Console.WriteLine(new_list.ToString_MY());

        Dictionary<double, double> dict = new Dictionary<double, double>();
        dict[1.0] = 0.3;
        dict[2.0] = 0.3;
        dict[3.0] = 0.3;
        dict[4.0] = 0.1;
        Console.WriteLine($"Math expectation: {dict.MathExpectation()}");
        Console.WriteLine($"Standard deviation: {dict.StandardDeviation(4, 2.5)}");
    }
}