﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace EventsProject
{
    enum Day { Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday }
    enum DayTime { Sunrise, Morning, Noon, Evening, Sunset }
    enum FlowerType { DayFlower, NightFlower }

    /* Клас 'Sun' має 2 події - зміна часу та зміна дня. Для виклику цих подій написано 2 функції, 
     * які перед тим як викликати подію перевіряють чи є підписки. Делегати задають функціям аргументи 'DayTime' та 'Day' відповідно,
     * щоб в подальшому інші об'єкти могли вибирати свою поведінку відповідно до дня/часу 
     */
    class Sun
    {
        public delegate void ChangeTimeHandler(DayTime time);
        public event ChangeTimeHandler? ChangeTimeEvent;

        public delegate void ChangeDayHandler(Day day);
        public event ChangeDayHandler? ChangeDayEvent;
        public void ChangeTime(DayTime time)
        {
            Console.WriteLine($"It is {Enum.GetName(typeof(DayTime), time)} now");
            if (ChangeTimeEvent != null) ChangeTimeEvent(time);
        }
        public void ChangeDay(Day day) 
        {
            Console.WriteLine($"Today is {Enum.GetName(typeof(Day), day)}");
            if (ChangeDayEvent != null) ChangeDayEvent(day);
        }
    }
    /* 
     * Оскільки 'DayFlower' та 'NightFlower' не дуже відрізняються я зробив абстрактний клас 'Flower'.
     * 'Flower' підписується на події сонця в конструкторі. 
     *
     * Коли сонце змінює день, то зменшується кількість днів цвітіння квіток, а коли змінюється час,
     * то вже підкласи оголошують свою поведінку відповідно до пори дня. В моєму випадку вони оголошують
     * коли відкритись.
     * 
     * 'Open()' та 'Close()' викликають відповідні події при умові, що є підписки на них.
     * 
     * Події приймають аргументом Flower. Це потрібно, щоб бджілка/метелик вибрали квітку відповідного типу.
     * Оскільки є базовий клас Flower, то квітки (І денні, і нічні) зручно тримати в масиві Flower[]. А також
     * зручно бджілку/метелика підписати на події всіх квіток через цей самий масив
     */

    abstract class Flower
    {
        public delegate void OpenHandler(Flower flower);
        public event OpenHandler? OpenEvent;
        public delegate void CloseHandler(Flower flower);
        public event CloseHandler? CloseEvent;
        public uint BloomDays { get; private set; }
        public string Name { get; init; }
        public FlowerType Type { get; init; }
        
        public Flower(uint days, string name, ref Sun sun) 
        { 
            BloomDays = days; 
            Name = name;
            sun.ChangeTimeEvent += TimeChangeResponse;
            sun.ChangeDayEvent += DayChangeResponse;
        }
        public abstract void TimeChangeResponse(DayTime time); // Коли відкритись оголошують підкласи
        void DayChangeResponse(Day day)
        {
            if (BloomDays != 0) BloomDays -= 1;
            if (BloomDays == 0) Console.WriteLine($"{Name} doesn't give pollen anymore");
        }
        public virtual void Open()
        {
            Console.WriteLine($"The '{Name}' opened up");
            if (OpenEvent != null) OpenEvent(this); // Говорю, що саме ця квітка (this) відкрилась
        }
        public virtual void Close()
        {
            Console.WriteLine($"The '{Name}' curled up");
            if (CloseEvent != null) CloseEvent(this); // Говорю, що саме ця квітка (this) закрилась
        }
    }
    class DayFlower : Flower
    {
        public DayFlower(uint days, string name, ref Sun sun) : base(days, name, ref sun) { Type = FlowerType.DayFlower; }
        public override void TimeChangeResponse(DayTime time) // Оголошую поведінку денної квітки відповідно до часу
        {
            switch (time)
            {
                case DayTime.Morning:
                    Open();
                    break;
                case DayTime.Noon:
                    HeatResponse();
                    break;
                case DayTime.Evening:
                    Close();
                    break;
            }
        }
        public void HeatResponse() // "У полудень згортають пелюстки"
        {
            Console.WriteLine($"The '{Name}' feels the heat");
        }
    }
    class NightFlower : Flower
    {
        public NightFlower(uint days, string name, ref Sun sun) : base(days, name, ref sun) { Type = FlowerType.NightFlower; }
        public override void TimeChangeResponse(DayTime time) // Оголошую поведінку нічної квітки відповідно до часу
        {
            switch (time)
            {
                case DayTime.Sunset:
                    Open();
                    break;
                case DayTime.Sunrise:
                    Close();
                    break;
            }
        }
    }

    /* Бджілка підписується на подію сонця 'ChangeTimeEvent' в конструкторі. Це необхідно,
     * щоб повідомити коли бджілка починає пошук пилка і коли йде відпочивати. За це відповідає
     * функція 'TimeChangeResponse(DayTime)'
     * 
     * Функція 'ConnectTo(Flower[])' просто підписує бджілку на відвідування всіх квіток, а 
     * 'VisitFlower(Flower)' - перевіряє, чи квітка денна, якщо так то чи квітка ще цвіте.
     * Якщо щось з цього не виконується, то бджілка не збиратиме пилок з неї
     */
    class Bee
    {
        public Bee(ref Sun sun)
        {
            sun.ChangeTimeEvent += TimeChangeResponse;
        }
        protected virtual void TimeChangeResponse(DayTime time)
        {
            switch (time)
            {
                case DayTime.Sunrise:
                    StartWorking();
                    break;
                case DayTime.Sunset:
                    FinishWorking();
                    break;
            }
        }
        protected virtual void  StartWorking()
        {
            Console.WriteLine("The bee starts looking for pollen");
        }
        protected virtual void  FinishWorking()
        {
            Console.WriteLine("The bee hides in the hive");
        }

        public virtual void ConnectTo(Flower[] flowers)
        {
            foreach (Flower flower in flowers)
            {
                flower.OpenEvent += VisitFlower;
            }
        }
        protected virtual void VisitFlower(Flower flower)
        {
            if (flower.Type != FlowerType.DayFlower || flower.BloomDays == 0) return;
            Console.WriteLine($"The bee collects pollen from '{flower.Name}'");
        }
    }

    /* Нічний метелик дуже схожий на бджілку, тому я вирішив наслідувати його від неї,
     * щоб не перевизначати метод 'ConnectTo(Flower[])'. В усьому іншому це та сама бджілка,
     * але нічна
     */
    class NightButterfly : Bee
    {
        public NightButterfly(ref Sun sun) : base(ref sun) {}
        protected override void TimeChangeResponse(DayTime time) // Працює по ночам
        {
            switch (time)
            {
                case DayTime.Evening:
                    StartWorking();
                    break;
                case DayTime.Sunrise:
                    FinishWorking();
                    break;
            }
        }
        protected override void StartWorking()
        {
            Console.WriteLine("Butterfly starts searching for flowers");
        }
        protected override void FinishWorking()
        {
            Console.WriteLine("Butterfly goes to sleep");
        }
        protected override void VisitFlower(Flower flower) // Відвідує тільки нічні квітки
        {
            if (flower.Type != FlowerType.NightFlower || flower.BloomDays == 0) return;
            Console.WriteLine($"The butterfly visits '{flower.Name}'");
        }
    }

    /*
     * Дівчинка мусить знати котрий сьогодні день, тому коли сонце змінює його, дівчика запам'ятовує його.
     * Для цього я підключив, до події 'ChangeDayEvent', функцію 'ChangeDayResponse' (Також через конструктор).
     * 
     * 'FlowerOpenResponse(Flower)' викликається коли квітка відкрилась. Оскільки дівчинка знає котрий сьогодні день, 
     * то для робочих днів вона робить фото з квіткою, в якої Type == NightFlower. Для вихідних відповідно з квітками в котрих Type == DayFlower
     */
    class Girl
    {
        public Day CurrentDay { get; private set; }
        public Girl(ref Sun sun)
        {
            sun.ChangeDayEvent += ChangeDayResponse;
        }
        public void ChangeDayResponse(Day day) // Запам'ятовуєм сьогоднішній день
        {
            CurrentDay = day;
        }
        public virtual void ConnectTo(Flower[] flowers) // Підключаємось до масиву квіток
        {
            foreach (Flower flower in flowers)
            {
                flower.OpenEvent += FlowerOpenResponse;
            }
        }
        private void FlowerOpenResponse(Flower flower)
        {
            switch (CurrentDay)
            {
                case Day.Monday:
                case Day.Tuesday:
                case Day.Wednesday:
                case Day.Thursday:
                case Day.Friday:
                    TakeSelfie(FlowerType.NightFlower, flower); // Для робочих днів робим фото з нічними квітами
                    break;
                case Day.Saturday:
                case Day.Sunday:
                    TakeSelfie(FlowerType.DayFlower, flower); // Для вихідних - з денними квітами
                    break;
            }
        }
        public void TakeSelfie(FlowerType type, Flower flower)
        {
            if (type != flower.Type) return; // Якщо переданий тип квітки не збігається з дійсністю, то не робим фото
            Console.WriteLine($"Girl takes a selfie with '{flower.Name}'");
        }
        
    }
}
