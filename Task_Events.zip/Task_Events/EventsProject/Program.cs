﻿using EventsProject;
using System.Diagnostics.CodeAnalysis;

// Створення об'єктів
Sun sun = new Sun();

Bee bee = new Bee(ref sun);
NightButterfly butterfly = new NightButterfly(ref sun);
Girl girl = new Girl(ref sun);

// Створення масиву квіток
Flower[] flowers = new Flower[4];
flowers[0] = new DayFlower(5, "Lily", ref sun);
flowers[1] = new DayFlower(3, "Rose", ref sun);
flowers[2] = new NightFlower(7, "Night-Blooming Jasmine", ref sun);
flowers[3] = new NightFlower(6, "Night Gladiolus", ref sun);

// Підключення об'єктів до квіток
bee.ConnectTo(flowers);
butterfly.ConnectTo(flowers);
girl.ConnectTo(flowers);


// Зовнішній цикл для днів, а внутрішній для часу
// Пройде 1 тиждень (7 днів)
Console.WriteLine("***************** Start *****************");
for (int i = 0; i < 7; i++)
{
    sun.ChangeDay((Day)i); // Перетворюю 'i' на відповідний день
    Console.Write("-----------------------------------------\n");
    for (int j = 0; j < 5; j++)
    {
        sun.ChangeTime((DayTime)j); // Перетворюю 'j' на відповідний час
        Console.ReadLine();
    }
    Console.Write("*****************************************\n");
}

Console.WriteLine("***************** Finish *****************");