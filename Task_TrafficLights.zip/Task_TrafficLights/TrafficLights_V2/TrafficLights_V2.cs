﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace TrafficLights_V2
{
    interface ITrafficLightsPart // Це будь-яка частина світлофора
    {
        // Кожна частина має внутрішній лічильник секунд та метод, який якимось чином реагує на подію таймера Elapsed.
        // Якщо раптом буде потрібен доступ до TrafficLights можна написати подію SecondPassed, яка будується на делегаті
        // public delegate SecondPassedHandler(object sender, ...), і кожного разу при виклику Elapsed викликати цю подію.
        // Звісно тоді доведеться підписувати частини світлофора до цієї події 
        string PartName { get; set; }
        uint SecondCounter { get; set; }
        void SecondPassedResponce(object? sender, ElapsedEventArgs? arg);
        // Можна дописати метод NightMode.
    }
    /*
     TrafficLights це "командний центр". Він потрібен, щоб впикати/вимикати атоматичний/ручний режими
     і просто керувати кожною частиною світлофора. Наприклад вмикати/вимикати нічний режим.
     */
    class TrafficLights
    {
        private System.Timers.Timer second_timer = new System.Timers.Timer(1000);
        private ITrafficLightsPart[] parts;
        public TrafficLights(params ITrafficLightsPart[] given_parts)
        {
            second_timer.AutoReset = true;
            parts = given_parts;
        }
        /*
         Одна з проблем це ручний режим. Я не придумав, як керувати кожною частиною окремо, 
         тому просто одночасно керую всіма головними частинами
        */
        public void HandMode()
        {
            string choise = "";
            Console.WriteLine("Увімкнути червоний: 1; Увімкнути жовтий: 2, Увімкнути зелений: 3; Вийти: 4");
            ITrafficLightsPart[] mainlight_parts = (from part in parts
                                            where part.GetType() == typeof(MainLights)
                                            select part).ToArray();
            while (choise != "4")
            {
                choise = Console.ReadLine();
                
                if (choise == "1")
                {
                    foreach (var mainlight in mainlight_parts)
                    {
                        ((MainLights)mainlight).SwitchToRed();
                    }
                }
                else if (choise == "2")
                {
                    foreach (var mainlight in mainlight_parts)
                    {
                        ((MainLights)mainlight).SwitchToYellow();
                    }
                }
                else if (choise == "3")
                {
                    foreach (var mainlight in mainlight_parts)
                    {
                        ((MainLights)mainlight).SwitchToGreen();
                    }
                }
            }
            Console.WriteLine("Ручний режим завершено");
        }
        /*
         В автоматичному режимі я просто підписую всі частини світлофора до події таймера і запускаю його.
         Я вирішив підписувати тут, бо необхідно також і відписати їх по завершенню програми. Тут це зручно зробити
         */
        public void AutomaticMode(bool turn_on)
        {
            if (turn_on)
            {
                foreach (ITrafficLightsPart part in parts)
                {
                    second_timer.Elapsed += part.SecondPassedResponce;
                }
                second_timer.Start();
            }
            else
            {
                second_timer.Stop();
                foreach (ITrafficLightsPart part in parts)
                {
                    second_timer.Elapsed -= part.SecondPassedResponce;
                }
            }
        }
    }
}
