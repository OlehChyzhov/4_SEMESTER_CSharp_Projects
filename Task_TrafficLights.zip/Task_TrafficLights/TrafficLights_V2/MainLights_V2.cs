﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace TrafficLights_V2
{
    public enum Light { Red, Yellow, Green }

    /*
     * MainLights це частина з 3 кольорами. Я вирішив зробити це окремою частиною,
     * щоб можна було розширити один світлофор на декілька доріг.
     */
    class MainLights : ITrafficLightsPart
    {
        public string PartName { get; set; }
        public uint SecondCounter { get; set; }

        private Light next_light;
        private int red_light_duration;
        private int yellow_light_duration;
        private int green_light_duration;

        // Зміна кольору це подія. sender - це конкретний екземпляр класу MainLights.
        // Як колір я передаю рядок, однак спершу я наслідівав клас EventArgs та передавав 
        // цей клас, але вирішив спростити програму, бо це було без потреби
        public delegate void LightChangedHandler(object? sender, string color);
        public event LightChangedHandler LightChanged;
        public MainLights(string name, int red, int yellow, int green, Light light = Light.Yellow)
        {
            PartName = name;
            red_light_duration = red;
            yellow_light_duration = yellow;
            green_light_duration = green;
            next_light = light;
        }
        public void SecondPassedResponce(object? sender, ElapsedEventArgs? arg)
        {
            SecondCounter++;
            AutomaticSwitchLights();
        }
        private void AutomaticSwitchLights()
        {
            if (next_light == Light.Red && SecondCounter >= green_light_duration)
            {
                SwitchToRed();
            }
            else if (next_light == Light.Yellow && SecondCounter >= red_light_duration)
            {
                SwitchToYellow();
            }
            else if (next_light == Light.Green && SecondCounter >= yellow_light_duration)
            {
                SwitchToGreen();
            }
        }
        public void SwitchToRed()
        {
            SecondCounter = 0;
            LightChanged(this, "Червоний");
            next_light = Light.Yellow;
        }
        public void SwitchToYellow()
        {
            SecondCounter = 0;
            LightChanged(this, "Жовтий");
            next_light = Light.Green;
        }
        public void SwitchToGreen()
        {
            SecondCounter = 0;
            LightChanged(this, "Зелений");
            next_light = Light.Red;
        }
    }
}
