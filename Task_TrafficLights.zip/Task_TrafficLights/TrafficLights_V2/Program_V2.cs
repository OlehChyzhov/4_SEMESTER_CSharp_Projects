﻿using System;
using System.Diagnostics;
using System.Net;
using System.Text;
using System.Timers;
using TrafficLights_V2;
class Informer 
{
    // Я не хотів засмічувати інші класи методами, які друкують інформацію на консоль, 
    // тому написав цей клас
    public void MainLightInformer(object? sender, string color)
    {
        MainLights main_lights = sender as MainLights;
        Console.WriteLine($"'{main_lights.PartName}' змінив колір на '{color}'");
    }
}
class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        Informer informer = new Informer();

        MainLights main_lights_1 = new MainLights("Головна дорога", 3, 3, 5, Light.Yellow);
        MainLights main_lights_2 = new MainLights("Дорога ліворуч", 3, 3, 5, Light.Red);
        TrafficLights lights = new TrafficLights(main_lights_1, main_lights_2);
        main_lights_1.LightChanged += informer.MainLightInformer;
        main_lights_2.LightChanged += informer.MainLightInformer;

        string user_input = "";
        bool auto_mode = false;
        Console.WriteLine("Увімкнути/Вимкнути автоматичний режим: 1");        
        Console.WriteLine("Увімкнути ручний режим: 2");        
        Console.WriteLine("Завершити програму: 3");        
        while (true)
        {
            user_input = Console.ReadLine();
            if (user_input == "1" && !auto_mode)
            {
                Console.WriteLine($"'{main_lights_1.PartName}' зараз 'червоний'");
                Console.WriteLine($"'{main_lights_2.PartName}' зараз 'зелений'");
                lights.AutomaticMode(true);
                auto_mode = true;
            }
            else if (user_input == "1" && auto_mode)
            {
                lights.AutomaticMode(false);
                auto_mode = false;
            }
            else if (user_input == "2")
            {
                lights.HandMode();
            }
            else if (user_input == "3")
            {
                break;
            }
        }
        
    }
}