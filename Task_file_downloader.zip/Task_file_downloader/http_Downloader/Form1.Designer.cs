﻿namespace http_Downloader
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            ProgressBar = new ProgressBar();
            DownloadButton = new Button();
            URL_TextBox = new TextBox();
            Lable1 = new Label();
            PerLable = new Label();
            label1 = new Label();
            FileNameTextBox = new TextBox();
            label3 = new Label();
            SuspendLayout();
            // 
            // ProgressBar
            // 
            ProgressBar.Location = new Point(254, 246);
            ProgressBar.Name = "ProgressBar";
            ProgressBar.Size = new Size(326, 29);
            ProgressBar.TabIndex = 0;
            // 
            // DownloadButton
            // 
            DownloadButton.Location = new Point(344, 321);
            DownloadButton.Name = "DownloadButton";
            DownloadButton.Size = new Size(123, 50);
            DownloadButton.TabIndex = 1;
            DownloadButton.Text = "Скачати";
            DownloadButton.UseVisualStyleBackColor = true;
            DownloadButton.Click += DownloadButton_Click;
            // 
            // URL_TextBox
            // 
            URL_TextBox.Location = new Point(168, 19);
            URL_TextBox.Multiline = true;
            URL_TextBox.Name = "URL_TextBox";
            URL_TextBox.Size = new Size(663, 130);
            URL_TextBox.TabIndex = 2;
            URL_TextBox.Text = resources.GetString("URL_TextBox.Text");
            URL_TextBox.TextAlign = HorizontalAlignment.Center;
            // 
            // Lable1
            // 
            Lable1.AutoSize = true;
            Lable1.Location = new Point(13, 26);
            Lable1.Name = "Lable1";
            Lable1.Size = new Size(87, 20);
            Lable1.TabIndex = 3;
            Lable1.Text = "Посилання";
            // 
            // PerLable
            // 
            PerLable.AutoSize = true;
            PerLable.Location = new Point(398, 289);
            PerLable.Name = "PerLable";
            PerLable.Size = new Size(29, 20);
            PerLable.TabIndex = 6;
            PerLable.Text = "0%";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 158);
            label1.Name = "label1";
            label1.Size = new Size(97, 20);
            label1.TabIndex = 9;
            label1.Text = "Назва файлу";
            // 
            // FileNameTextBox
            // 
            FileNameTextBox.Location = new Point(168, 155);
            FileNameTextBox.Multiline = true;
            FileNameTextBox.Name = "FileNameTextBox";
            FileNameTextBox.Size = new Size(663, 59);
            FileNameTextBox.TabIndex = 8;
            FileNameTextBox.Text = "Example.exeNEXTAnimal.jpgNEXTApplication.exe";
            FileNameTextBox.TextAlign = HorizontalAlignment.Center;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.Control;
            label3.ForeColor = SystemColors.ControlDark;
            label3.Location = new Point(294, 407);
            label3.Name = "label3";
            label3.Size = new Size(229, 20);
            label3.TabIndex = 10;
            label3.Text = "Завантажиться на робочий стіл";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(858, 450);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(FileNameTextBox);
            Controls.Add(PerLable);
            Controls.Add(Lable1);
            Controls.Add(URL_TextBox);
            Controls.Add(DownloadButton);
            Controls.Add(ProgressBar);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ProgressBar ProgressBar;
        private Button DownloadButton;
        private TextBox URL_TextBox;
        private Label Lable1;
        private Label PerLable;
        private Label label1;
        private TextBox FileNameTextBox;
        private Label label3;
    }
}
