﻿namespace TextCoder
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DirectoryPathTextBox = new TextBox();
            label1 = new Label();
            CodeButton = new Button();
            label2 = new Label();
            FileNameTextBox = new TextBox();
            DecodeButton = new Button();
            label3 = new Label();
            KeyWordTextBox = new TextBox();
            ProgressBar = new ProgressBar();
            SuspendLayout();
            // 
            // DirectoryPathTextBox
            // 
            DirectoryPathTextBox.Location = new Point(275, 21);
            DirectoryPathTextBox.Name = "DirectoryPathTextBox";
            DirectoryPathTextBox.Size = new Size(553, 27);
            DirectoryPathTextBox.TabIndex = 0;
            DirectoryPathTextBox.Text = "C:\\Users\\iamol\\OneDrive\\Desktop\\JustFolder";
            DirectoryPathTextBox.TextAlign = HorizontalAlignment.Center;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 28);
            label1.Name = "label1";
            label1.Size = new Size(231, 20);
            label1.TabIndex = 1;
            label1.Text = "Повний шлях до робочої папки";
            // 
            // CodeButton
            // 
            CodeButton.Location = new Point(275, 246);
            CodeButton.Name = "CodeButton";
            CodeButton.Size = new Size(200, 50);
            CodeButton.TabIndex = 3;
            CodeButton.Text = "Закодувати";
            CodeButton.UseVisualStyleBackColor = true;
            CodeButton.Click += CodeButton_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 70);
            label2.Name = "label2";
            label2.Size = new Size(212, 20);
            label2.TabIndex = 5;
            label2.Text = "Назва файлу з розширенням";
            // 
            // FileNameTextBox
            // 
            FileNameTextBox.Location = new Point(275, 63);
            FileNameTextBox.Name = "FileNameTextBox";
            FileNameTextBox.Size = new Size(186, 27);
            FileNameTextBox.TabIndex = 4;
            FileNameTextBox.Text = "Secret_text.txt";
            FileNameTextBox.TextAlign = HorizontalAlignment.Center;
            // 
            // DecodeButton
            // 
            DecodeButton.Location = new Point(497, 246);
            DecodeButton.Name = "DecodeButton";
            DecodeButton.Size = new Size(200, 50);
            DecodeButton.TabIndex = 6;
            DecodeButton.Text = "Розкодувати";
            DecodeButton.UseVisualStyleBackColor = true;
            DecodeButton.Click += DecodeButton_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 119);
            label3.Name = "label3";
            label3.Size = new Size(105, 20);
            label3.TabIndex = 8;
            label3.Text = "Кодове слово";
            // 
            // KeyWordTextBox
            // 
            KeyWordTextBox.Location = new Point(275, 112);
            KeyWordTextBox.Name = "KeyWordTextBox";
            KeyWordTextBox.Size = new Size(186, 27);
            KeyWordTextBox.TabIndex = 7;
            KeyWordTextBox.Text = "Key";
            KeyWordTextBox.TextAlign = HorizontalAlignment.Center;
            // 
            // ProgressBar
            // 
            ProgressBar.Location = new Point(248, 201);
            ProgressBar.Name = "ProgressBar";
            ProgressBar.Size = new Size(480, 29);
            ProgressBar.TabIndex = 9;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(982, 450);
            Controls.Add(ProgressBar);
            Controls.Add(label3);
            Controls.Add(KeyWordTextBox);
            Controls.Add(DecodeButton);
            Controls.Add(label2);
            Controls.Add(FileNameTextBox);
            Controls.Add(CodeButton);
            Controls.Add(label1);
            Controls.Add(DirectoryPathTextBox);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox DirectoryPathTextBox;
        private Label label1;
        private Button CodeButton;
        private Label label2;
        private TextBox FileNameTextBox;
        private Button DecodeButton;
        private Label label3;
        private TextBox KeyWordTextBox;
        private ProgressBar ProgressBar;
    }
}
