﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_project
{
    class Car
    {
        public string Name { get; set; }
        public int MaxSpeed { get; set; }
        public int ProduceYear { get; set; }
        public string ProduceCountry { get; set; }
        public Car(string name, int speed, int year, string country) 
        { 
            Name = name; MaxSpeed = speed; ProduceYear = year; ProduceCountry = country;
        }
        public override string ToString()
        {
            return $"Машина {Name} має максимальну швидкiсть {MaxSpeed} км/год. Виготовлена {ProduceYear} в країні '{ProduceCountry}'";
        }
    }
    class Person
    {
        public uint Id { get; set; }
        public string Name { get; set; }
        public Person(uint id, string name) { Id = id; Name = name; }
    }
    class Grades
    {
        public uint StudentId { get; set; }
        public int[] data;
        public Grades(uint id, int[] marks) { StudentId = id; data = marks; }
    }
}
