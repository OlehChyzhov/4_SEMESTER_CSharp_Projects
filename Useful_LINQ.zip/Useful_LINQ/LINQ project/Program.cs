﻿using LINQ_project;
using System.Reflection.Metadata.Ecma335;
using System.Text;

class Program
{
    // Я не дуже зрозумів, що малось на увазі під "нетривіальне використання", тому в першому прикладі я показав,
    // як використовується LINQ загалом. Там є різноманітні приклади написання звичайних та функціональних запитів.
    // В наступних прикладах показано цікаві можливості, про які я дізнався під час вивчення LINQ.
    static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;

        Console.WriteLine("****************************Приклад_1****************************");
        List<Car> cars = Collections.GetCars();
        
        // В цьому прикладі я вибрав 3 найшвидші наявні машини
        var fastest_cars = (from car in cars
                          orderby car.MaxSpeed descending
                          select car).Take(3).ToList();
        Console.WriteLine("Найшвидшi машини:");
        fastest_cars.ForEach(car => Console.WriteLine(car));

        // Тут я хотів продемонструвати різницю між Concat та Union. Різниця в тому, що Union вилучає дублікати
        // Також можна побачити, як працює ThenBy.
        var concat_example = cars.Concat(cars).OrderBy(car => car.MaxSpeed).ToList();
        var union_example = cars.Union(cars).OrderBy(car => car.MaxSpeed).ThenBy(car => car.ProduceYear).ToList();
        Console.WriteLine("\n'Concat' машини:");
        concat_example.ForEach(car => Console.WriteLine(car));
        Console.WriteLine("\n'Union' машини:");
        union_example.ForEach(car => Console.WriteLine(car));

        // Any - дуже корисний функціональний запит. Повертає bool і приймає предикат
        if (cars.Any(car => car.ProduceYear < 1900))
        {
            Console.WriteLine("\nУ гаражі є машини, які виготовили раніше 1900 року\n");
        }

        // В наступному запиті я групую машини по країні виробництва та рахую їх кількості
        var groupped_cars = (from car in cars
                             group car by car.ProduceCountry
                             into car_groups
                             select car_groups).ToList();

        groupped_cars.ForEach(group => Console.WriteLine($"{group.Key} - {group.Count()}"));

        // Тут я продемонстрував роботу where
        var where_example = (from car in cars
                          where car.MaxSpeed > 50 && car.ProduceYear < 2000
                          select car).ToList();

        Console.WriteLine("\nПриклад використання 'Where':");
        where_example.ForEach(car => Console.WriteLine(car));

        // Тепер я вирішив продемонструвати роботу відкладеного запиту.
        // Для цього я додав ще одну машину та повторив попередній запит:
        var postponed_query = from car in cars
                              where car.MaxSpeed > 50 && car.ProduceYear < 2000
                              select car;

        cars.Add(new Car("BMW", 60, 1999, "Україна"));

        Console.WriteLine("\nВідкладений запит:");
        foreach (var car in postponed_query) //ForEach неможливо використати
        {
            Console.WriteLine(car);
        }

        Console.WriteLine("****************************Приклад_2****************************");
        // Створення нових типів
        /*
         * LINQ дозволяє створювати нові анонімні типи під час виконяння програми. Тут я використав дані з "Person" та "Grades".
         */
        List<Person> people = Collections.GetPeople();
        List<Grades> marks = Collections.GetGrades();

        Console.WriteLine("Новий анонiмний тип:");
        var students = (from person in people
                       join mark in marks on person.Id equals mark.StudentId
                       select new
                       {
                           Name = person.Name,
                           Marks = mark.data
                       }).ToList();
        students.ForEach(student => Console.WriteLine($"Студент: {student.Name}\nОцiнки: {string.Join("; ", student.Marks)}\n"));

        /*
         * Окрім створення анонімних типів можна також оголошувати нові екземпляри вже існуючих типів.
         */
        Console.WriteLine("Новi екземпляри вже iснуючого типу:");
        var changed_people = (from person in people
                              select new Person(person.Id + 1, person.Name)).ToList();
        changed_people.ForEach(person => Console.WriteLine($"Людина: {person.Name}\nНомер: {person.Id}\n"));
        
        Console.WriteLine("****************************Приклад_3****************************");
        /*
         * За допомогою SelectMany можна створити декартів добуток двох множин
         */
        Console.WriteLine("Декартiв добуток:");
        string[] letters = { "A", "B", "C", "D" };
        int[] numbers = { 1, 2, 3 };

        var fields = letters.SelectMany(letter => numbers, (letter, number) => $"{letter}{number}").ToList();
        fields.ForEach(field => Console.Write($"{field} "));
    }
}