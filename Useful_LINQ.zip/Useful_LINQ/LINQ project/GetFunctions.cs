﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_project
{
    static class Collections
    {
        public static List<Person> GetPeople()
        {
            List<Person> people = new List<Person>();
            people.Add(new Person(4, "Max"));
            people.Add(new Person(6, "Tom"));
            people.Add(new Person(3, "Kim"));
            people.Add(new Person(1, "James"));
            people.Add(new Person(2, "Sophia"));
            people.Add(new Person(5, "Jane"));
            return people;
        }
        public static List<Grades> GetGrades()
        {
            List<Grades> grades = new List<Grades>();
            grades.Add(new Grades(1, new int[] { 1, 5, 6, 2 }));
            grades.Add(new Grades(2, new int[] { 6, 2, 9, 4 }));
            grades.Add(new Grades(3, new int[] { 6, 1, 3 }));
            grades.Add(new Grades(4, new int[] { 2, 6 }));
            grades.Add(new Grades(5, new int[] { 9, 7, 5, 3 }));
            grades.Add(new Grades(6, new int[] { 3, 2, 6, 8 }));
            return grades;
        }
        public static List<Car> GetCars()
        {
            List<Car> cars = new List<Car>();
            cars.Add(new Car("BMW", 120, 2022, "Україна"));
            cars.Add(new Car("Jeep", 110, 2019, "США"));
            cars.Add(new Car("Mazda", 85, 1980, "Китай"));
            cars.Add(new Car("MG", 220, 2024, "Україна"));
            cars.Add(new Car("Suzuki", 20, 1800, "Китай"));
            cars.Add(new Car("Skoda", 110, 2018, "Китай"));
            cars.Add(new Car("SEAT", 98, 2010, "Китай"));
            cars.Add(new Car("Tesla", 110, 2010, "США"));
            return cars;
        }
    }
}
