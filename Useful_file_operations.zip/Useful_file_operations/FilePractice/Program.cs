﻿using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

class Program
{
    // Binary read/write practice
    static void BinaryReadWritePractice()
    {
        int readen_value = 0;

        using (FileStream stream = File.Open(@"D:\Programming\C#\FilePractice\FilePractice\write.txt", FileMode.Open, FileAccess.ReadWrite))
        {
            using (BinaryWriter writer = new BinaryWriter(stream, Encoding.UTF8, true))
            {
                writer.Write(5);
            }

            stream.Seek(0, SeekOrigin.Begin);
            using (BinaryReader reader = new BinaryReader(stream))
            {
                readen_value = reader.ReadInt32();
            }
        }

        Console.WriteLine(readen_value);
    }
    // Buffered stream practice
    static void BufferedStreamPractice()
    {
        using (FileStream stream = File.Open(@"D:\Programming\C#\FilePractice\FilePractice\write.txt", FileMode.Open, FileAccess.ReadWrite))
        using (BufferedStream buffer = new BufferedStream(stream))
        {
            using (StreamWriter writer = new StreamWriter(buffer))
            {
                writer.Write("Test");
                //buffer.Flush();
            }
        }
    }
    //Directory practice
    static void CleanUpDirectories(string path)
    {
        Console.WriteLine("Delete all directories?: 1/0");
        int choice = int.Parse(Console.ReadLine());
        if (choice == 1)
        {
            var directories = Directory.EnumerateDirectories(path);
            foreach (var directory in directories)
            {
                Directory.Delete(directory, true);
            }
            Directory.Delete(path);
        }
    }
    static void CreateFilesIn(string path, int amount)
    {
        for (int i = 0; i < amount; i++)
        {
            using (StreamWriter writer = new StreamWriter(Path.Combine(path, $"file{i}.txt")))
            {
                writer.Write($"Important text #{i}");
            }
        }
    }
    static void CreateRecursiveDirectories(string path, int amount)
    {
        for (int i = 0; i < amount; i++)
        {
            path = Path.Combine(path, $"Directory{i}");
            Directory.CreateDirectory(path);
        }
        CreateFilesIn(path, 1);
    }
    static void MoveFileFromTo(string from, string to, Predicate<string> condition)
    {
        IEnumerable<string> files = Directory.EnumerateFiles(from);
        foreach (string file in files)
        {
            string file_name = file.Substring(from.Length + 1, 9);
            if (condition(file_name))
            {
                try
                {
                    Directory.Move(file, Path.Combine(to, file_name));
                }
                catch (Exception ex)
                {
                    Console.WriteLine("**************Exeption**************");
                    Console.WriteLine(ex.Message);
                    Console.WriteLine("************************************");
                }
            }
        }
    }
    static void DirectoryPractice()
    {
        string path = @"D:\Programming\C#\FilePractice\FilePractice";

        Console.WriteLine("Enter directory name:");
        string name = Console.ReadLine();
        path = Path.Combine(path, name);
        Directory.CreateDirectory(path);

        string[] directory_names = { "ReadDirectory", "WriteDirectory", "RecursionDirectory" };
        for (int i = 0; i < directory_names.Length; i++)
        {
            string directory_name = Path.Combine(path, directory_names[i]);
            Directory.CreateDirectory(directory_name);
        }
        CreateFilesIn(Path.Combine(path, directory_names[0]), 5);

        string new_path = Path.Combine(path, directory_names[2]);
        CreateRecursiveDirectories(new_path, 5);

        string read_directory_path = Path.Combine(path, directory_names[0]);
        string write_directory_path = Path.Combine(path, directory_names[1]);

        MoveFileFromTo(read_directory_path, write_directory_path, (string file_name) => { return file_name.Contains("2"); });
        CleanUpDirectories(path);
    }
    // DriveInfo practice
    static void DriveInfoPractice()
    {
        DriveInfo[] drives = DriveInfo.GetDrives();
        long largest_file_size = 0;
        string largest_file_name = "";
        foreach (DriveInfo drive in drives)
        {
            foreach (FileInfo file in drive.RootDirectory.EnumerateFiles("*", SearchOption.AllDirectories))
            {
                if (file.Length > largest_file_size)
                {
                    largest_file_size = file.Length;
                    largest_file_name = file.FullName;
                }
            }
        }

        Console.WriteLine($"Largest file: {largest_file_name} | {largest_file_size}");
    }
    // Serializer practice
    static void SerializePractice()
    {
        XmlSerializer serializer = new XmlSerializer(typeof(Person));
        string xml;
        using (StringWriter writer = new StringWriter())
        {
            Person person = new Person("Oleg", 19);
            serializer.Serialize(writer, person);
            xml = writer.ToString();
        }
        Console.WriteLine(xml);
        using (StringReader reader = new StringReader(xml))
        {
            Person person = (Person)serializer.Deserialize(reader);
            Console.WriteLine(person);
        }
    }
    static void Main(string[] agrs)
    {
        DirectoryPractice();
        Console.ReadLine();
    }
}

[Serializable]
public class Person
{
    public string Name { get; set; }
    public int Age { get; set; }
    public Person()
    {
        Name = "base"; Age = 0;
    }
    public Person(string name, int age)
    {
        Name = name; Age = age;
    }
    public override string ToString()
    {
        return $"Name: {Name} | Age: {Age}";
    }
}